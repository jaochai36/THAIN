import { type ReactNode, useEffect, useMemo, useState } from "react";

type StepId = 1 | 2 | 3 | 4 | 5;

type Character = {
  id: string;
  name: string;
  role: string;
  bodyShape: "petite" | "balanced" | "tall";
  skinTone: string;
  outfitColor: string;
  hairColor: string;
  personality: string;
  goal: string;
};

type StoryPage = {
  page: number;
  label: string;
  storyText: string;
  scene: string;
  studentPrompt: string;
};

type BuilderState = {
  fullName: string;
  nickname: string;
  grade: string;
  teamName: string;
  ebookTitle: string;
  theme: string;
  styleId: string;
  narrationTone: "classic" | "cinematic" | "gentle";
  polishLevel: 1 | 2 | 3;
  characters: Character[];
  storyboard: StoryPage[];
};

const STORAGE_KEY = "thian-apple-builder-v2";

const STYLES = [
  {
    id: "thai-classic",
    name: "Thai Classic Illustration",
    subtitle: "ลายไทยร่วมสมัย โทนอุ่น คมชัดระดับหนังสือมืออาชีพ",
    visualKeywords: "thai mural inspired, handcrafted texture, elegant light, premium print look",
    palette: "warm gold, ivory, deep indigo",
  },
  {
    id: "anime-thai",
    name: "Anime x Thai Heritage",
    subtitle: "เส้นสะอาด องค์ประกอบร่วมสมัย พร้อมอัตลักษณ์ไทยชัดเจน",
    visualKeywords: "anime cinematic frame, refined line art, thai motifs, emotional close-up",
    palette: "soft peach, sky blue, warm neutral",
  },
  {
    id: "picturebook",
    name: "Modern Picture Book",
    subtitle: "อ่านง่ายสำหรับนักเรียน ภาพนุ่มแต่รายละเอียดครบ",
    visualKeywords: "children picture book, watercolor depth, layered composition, story-first",
    palette: "muted pastel, clean paper white",
  },
  {
    id: "editorial",
    name: "Editorial Educational",
    subtitle: "สไตล์สารคดีภาพสำหรับงานโรงเรียนและนิทรรศการ",
    visualKeywords: "editorial illustration, educational clarity, realistic proportion",
    palette: "charcoal, cream, accent blue",
  },
];

const PAGE_TEMPLATES = [
  "ปกเรื่อง",
  "คำนำ",
  "แนะนำตัวละคร",
  "จุดเริ่มต้นของปัญหา",
  "เริ่มออกเดินทาง",
  "ค้นพบข้อมูลสำคัญ",
  "ลงมือทำจริง",
  "เกิดอุปสรรค",
  "ได้ผู้ช่วยหรือเบาะแส",
  "ก้าวผ่านสำเร็จ",
  "บทเรียนที่ได้รับ",
  "สรุปและชวนคิดต่อ",
];

const SKIN_TONES = ["#F6D5BE", "#E9BE99", "#D7A37C", "#BC835C", "#8F5D3D"];
const OUTFIT_COLORS = ["#1D4ED8", "#0F766E", "#B91C1C", "#7C3AED", "#111827", "#D97706"];
const HAIR_COLORS = ["#111827", "#3F3F46", "#854D0E", "#9A3412", "#0F172A"];

const STEP_META = [
  { id: 1 as StepId, title: "ข้อมูลโครงการ" },
  { id: 2 as StepId, title: "ธีมและสไตล์" },
  { id: 3 as StepId, title: "Character Studio" },
  { id: 4 as StepId, title: "Storyboard 12 หน้า" },
  { id: 5 as StepId, title: "Prompt Studio" },
];

const createInitialState = (): BuilderState => ({
  fullName: "",
  nickname: "",
  grade: "",
  teamName: "",
  ebookTitle: "",
  theme: "",
  styleId: "thai-classic",
  narrationTone: "classic",
  polishLevel: 2,
  characters: [
    {
      id: crypto.randomUUID(),
      name: "",
      role: "ตัวเอก",
      bodyShape: "balanced",
      skinTone: SKIN_TONES[1],
      outfitColor: OUTFIT_COLORS[0],
      hairColor: HAIR_COLORS[0],
      personality: "",
      goal: "",
    },
  ],
  storyboard: PAGE_TEMPLATES.map((label, i) => ({
    page: i + 1,
    label,
    storyText: "",
    scene: "",
    studentPrompt: "",
  })),
});

function Icon({ name, className = "h-5 w-5" }: { name: string; className?: string }) {
  const common = "fill-none stroke-current stroke-[1.8]";
  if (name === "book") {
    return (
      <svg viewBox="0 0 24 24" className={className}>
        <path className={common} d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21V5.5Z" />
        <path className={common} d="M8 7h8M8 11h8" />
      </svg>
    );
  }
  if (name === "spark") {
    return (
      <svg viewBox="0 0 24 24" className={className}>
        <path className={common} d="m12 3 2.2 4.8L19 10l-4.8 2.2L12 17l-2.2-4.8L5 10l4.8-2.2L12 3Z" />
      </svg>
    );
  }
  if (name === "user") {
    return (
      <svg viewBox="0 0 24 24" className={className}>
        <circle className={common} cx="12" cy="8" r="3.5" />
        <path className={common} d="M4.5 20a7.5 7.5 0 0 1 15 0" />
      </svg>
    );
  }
  if (name === "wand") {
    return (
      <svg viewBox="0 0 24 24" className={className}>
        <path className={common} d="m4 20 10-10" />
        <path className={common} d="m14 4 1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2Z" />
        <path className={common} d="m18 11 .7 1.4L20 13l-1.3.6L18 15l-.7-1.4L16 13l1.3-.6L18 11Z" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 24 24" className={className}>
      <circle className={common} cx="12" cy="12" r="8" />
    </svg>
  );
}

function CharacterPreview({ character }: { character: Character }) {
  const width = character.bodyShape === "petite" ? 26 : character.bodyShape === "tall" ? 34 : 30;
  return (
    <div className="relative h-28 w-24 overflow-hidden rounded-2xl bg-gradient-to-b from-white to-zinc-100 ring-1 ring-zinc-200">
      <svg viewBox="0 0 120 140" className="h-full w-full">
        <circle cx="60" cy="36" r="20" fill={character.skinTone} />
        <path d="M40 28c4-14 36-14 40 0v10H40V28Z" fill={character.hairColor} />
        <rect x={60 - width / 2} y="58" width={width} height="52" rx="12" fill={character.outfitColor} />
        <rect x="42" y="110" width="14" height="20" rx="6" fill={character.skinTone} />
        <rect x="64" y="110" width="14" height="20" rx="6" fill={character.skinTone} />
      </svg>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/10 to-transparent p-1 text-center text-[10px] font-medium text-zinc-700">
        Preview
      </div>
    </div>
  );
}

export default function App() {
  const [step, setStep] = useState<StepId>(1);
  const [toast, setToast] = useState("");
  const [state, setState] = useState<BuilderState>(createInitialState);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as BuilderState;
        setState(parsed);
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const selectedStyle = STYLES.find((item) => item.id === state.styleId) ?? STYLES[0];
  const prompts = useMemo(() => {
    return state.storyboard.map((page) => {
      const studentBase = createStudentBasePrompt(page, state, selectedStyle);
      const polished = createPolishedPrompt(page, state, selectedStyle);
      const narration = createPolishedNarration(page.storyText, state.narrationTone);
      return { ...page, studentBase, polished, narration };
    });
  }, [state, selectedStyle]);

  const progress = (step / STEP_META.length) * 100;

  const goNext = () => {
    const issue = validateStep(step, state);
    if (issue) {
      setToast(issue);
      return;
    }
    setStep((prev) => (prev < 5 ? ((prev + 1) as StepId) : prev));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const goPrev = () => {
    setStep((prev) => (prev > 1 ? ((prev - 1) as StepId) : prev));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const addCharacter = () => {
    if (state.characters.length >= 3) {
      setToast("เพิ่มตัวละครได้สูงสุด 3 ตัว");
      return;
    }
    setState((prev) => ({
      ...prev,
      characters: [
        ...prev.characters,
        {
          id: crypto.randomUUID(),
          name: "",
          role: "ตัวรอง",
          bodyShape: "balanced",
          skinTone: SKIN_TONES[2],
          outfitColor: OUTFIT_COLORS[2],
          hairColor: HAIR_COLORS[1],
          personality: "",
          goal: "",
        },
      ],
    }));
  };

  const updateCharacter = (id: string, patch: Partial<Character>) => {
    setState((prev) => ({
      ...prev,
      characters: prev.characters.map((char) => (char.id === id ? { ...char, ...patch } : char)),
    }));
  };

  const randomizeCharacterLook = (id: string) => {
    const random = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];
    updateCharacter(id, {
      bodyShape: random(["petite", "balanced", "tall"]),
      skinTone: random(SKIN_TONES),
      outfitColor: random(OUTFIT_COLORS),
      hairColor: random(HAIR_COLORS),
    });
  };

  const copyAllPrompts = async () => {
    const text = prompts
      .map(
        (item) =>
          `หน้า ${item.page} ${item.label}\nPrompt ตั้งต้น:\n${item.studentBase}\n\nPrompt เกลาภาษา:\n${item.polished}\n\nบทบรรยาย:\n${item.narration}\n`,
      )
      .join("\n-----------------------\n\n");
    await navigator.clipboard.writeText(text);
    setToast("คัดลอกชุด Prompt แล้ว");
  };

  const exportTxt = () => {
    const payload = prompts
      .map(
        (item) =>
          `หน้า ${item.page} ${item.label}\nPrompt ตั้งต้น:\n${item.studentBase}\n\nPrompt เกลา:\n${item.polished}\n\nบทบรรยายเกลา:\n${item.narration}`,
      )
      .join("\n\n================================\n\n");
    const blob = new Blob([payload], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${state.ebookTitle || "storyboard"}-prompt-kit.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${state.ebookTitle || "project"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f7] text-zinc-900">
      <header className="sticky top-0 z-40 border-b border-zinc-200/70 bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-zinc-900 text-white">
              <Icon name="book" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs tracking-[0.16em] text-zinc-500">THIAN PROMPT STUDIO</p>
              <h1 className="text-lg font-semibold">เทียนปัญญา E-Book Builder</h1>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-zinc-500">ขั้นตอน {step} / 5</p>
            <p className="text-sm font-medium text-zinc-700">{state.nickname || state.fullName || "ยังไม่ระบุผู้สร้าง"}</p>
          </div>
        </div>
        <div className="mx-auto h-1 w-full max-w-6xl overflow-hidden bg-zinc-200">
          <div className="h-full bg-zinc-900 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl px-6 pb-24 pt-10">
        <nav className="mb-10 grid gap-2 md:grid-cols-5">
          {STEP_META.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setStep(item.id)}
              className={`rounded-2xl px-4 py-3 text-left text-sm transition ${step === item.id ? "bg-zinc-900 text-white" : "bg-white text-zinc-500 ring-1 ring-zinc-200 hover:text-zinc-800"}`}
            >
              <p className="text-xs tracking-wide">STEP {item.id}</p>
              <p className="mt-1 font-medium">{item.title}</p>
            </button>
          ))}
        </nav>

        <section key={step} className="step-enter space-y-8">
          {step === 1 && (
            <div className="space-y-6">
              <SectionHead
                icon="user"
                title="เริ่มแบบง่าย และเก็บข้อมูลเฉพาะที่จำเป็น"
                subtitle="ปรับให้กรอกง่ายขึ้น เพื่อให้นักเรียนเข้าสู่ Storyboard ได้เร็วขึ้น"
              />
              <div className="grid gap-4 md:grid-cols-2">
                <Field label="ชื่อ-นามสกุล" required>
                  <input
                    value={state.fullName}
                    onChange={(e) => setState((p) => ({ ...p, fullName: e.target.value }))}
                    className={inputClass}
                    placeholder="เช่น เด็กหญิงใจดี มานะ"
                  />
                </Field>
                <Field label="ชื่อเล่น" required>
                  <input
                    value={state.nickname}
                    onChange={(e) => setState((p) => ({ ...p, nickname: e.target.value }))}
                    className={inputClass}
                    placeholder="เช่น ใจดี"
                  />
                </Field>
                <Field label="ชั้นเรียน" required>
                  <input
                    value={state.grade}
                    onChange={(e) => setState((p) => ({ ...p, grade: e.target.value }))}
                    className={inputClass}
                    placeholder="เช่น ม.2/1"
                  />
                </Field>
                <Field label="ชื่อทีม" required>
                  <input
                    value={state.teamName}
                    onChange={(e) => setState((p) => ({ ...p, teamName: e.target.value }))}
                    className={inputClass}
                    placeholder="เดี่ยวหรือกลุ่ม"
                  />
                </Field>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-8">
              <SectionHead
                icon="spark"
                title="กำหนดธีมก่อน แล้วค่อยเลือกสไตล์ภาพ"
                subtitle="แนวทางนี้ทำให้ Prompt ที่เกลาออกมาไม่หลุดบริบท และคุมโทนทั้งเล่มได้จริง"
              />
              <Field label="ชื่อ E-Book" required>
                <input
                  value={state.ebookTitle}
                  onChange={(e) => setState((p) => ({ ...p, ebookTitle: e.target.value }))}
                  className={inputClass}
                  placeholder="เช่น เทียนแห่งความทรงจำ"
                />
              </Field>
              <Field label="คำถามหลักหรือธีมของเรื่อง" required>
                <textarea
                  value={state.theme}
                  onChange={(e) => setState((p) => ({ ...p, theme: e.target.value }))}
                  className={textAreaClass}
                  placeholder="เช่น เทียนพรรษาช่วยเชื่อมความทรงจำระหว่างรุ่นปู่กับรุ่นหลานอย่างไร"
                />
              </Field>
              <div className="space-y-3">
                <p className="text-sm font-medium text-zinc-700">สไตล์ภาพหลัก</p>
                <div className="grid gap-3 md:grid-cols-2">
                  {STYLES.map((style) => (
                    <button
                      key={style.id}
                      type="button"
                      onClick={() => setState((p) => ({ ...p, styleId: style.id }))}
                      className={`rounded-3xl p-5 text-left ring-1 transition ${state.styleId === style.id ? "bg-zinc-900 text-white ring-zinc-900" : "bg-white text-zinc-800 ring-zinc-200 hover:ring-zinc-400"}`}
                    >
                      <p className="text-base font-semibold">{style.name}</p>
                      <p className={`mt-2 text-sm ${state.styleId === style.id ? "text-zinc-200" : "text-zinc-500"}`}>{style.subtitle}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-8">
              <SectionHead
                icon="user"
                title="Character Studio พร้อมภาพร่างน่ารัก"
                subtitle="เพิ่มความสนุกด้วยรูปร่าง โทนผิว สีผม สีชุด แล้วระบบจะคงคาแรกเตอร์ไปทุก Prompt"
              />
              {state.characters.map((char, idx) => (
                <div key={char.id} className="rounded-3xl bg-white p-6 ring-1 ring-zinc-200 transition hover:ring-zinc-300">
                  <div className="mb-4 flex items-center justify-between">
                    <p className="text-sm font-semibold text-zinc-700">ตัวละคร {idx + 1}</p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => randomizeCharacterLook(char.id)}
                        className="rounded-full border border-zinc-300 px-3 py-1 text-xs text-zinc-600 hover:bg-zinc-100"
                      >
                        สุ่มลุค
                      </button>
                      {state.characters.length > 1 && (
                        <button
                          type="button"
                          onClick={() =>
                            setState((p) => ({ ...p, characters: p.characters.filter((item) => item.id !== char.id) }))
                          }
                          className="rounded-full border border-zinc-300 px-3 py-1 text-xs text-zinc-600 hover:bg-zinc-100"
                        >
                          ลบ
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="grid gap-5 md:grid-cols-[1fr_auto]">
                    <div className="grid gap-4 md:grid-cols-2">
                      <Field label="ชื่อตัวละคร" required={idx === 0}>
                        <input
                          value={char.name}
                          onChange={(e) => updateCharacter(char.id, { name: e.target.value })}
                          className={inputClass}
                          placeholder="เช่น น้องแก้ว"
                        />
                      </Field>
                      <Field label="บทบาท">
                        <input
                          value={char.role}
                          onChange={(e) => updateCharacter(char.id, { role: e.target.value })}
                          className={inputClass}
                          placeholder="ตัวเอก / ผู้ช่วย / ครู"
                        />
                      </Field>
                      <Field label="บุคลิกเด่น">
                        <input
                          value={char.personality}
                          onChange={(e) => updateCharacter(char.id, { personality: e.target.value })}
                          className={inputClass}
                          placeholder="เช่น ช่างสังเกต ใจเย็น"
                        />
                      </Field>
                      <Field label="เป้าหมายของตัวละคร">
                        <input
                          value={char.goal}
                          onChange={(e) => updateCharacter(char.id, { goal: e.target.value })}
                          className={inputClass}
                          placeholder="สิ่งที่อยากทำให้สำเร็จ"
                        />
                      </Field>
                      <Field label="รูปร่าง">
                        <select
                          value={char.bodyShape}
                          onChange={(e) => updateCharacter(char.id, { bodyShape: e.target.value as Character["bodyShape"] })}
                          className={inputClass}
                        >
                          <option value="petite">Petite</option>
                          <option value="balanced">Balanced</option>
                          <option value="tall">Tall</option>
                        </select>
                      </Field>
                      <ColorField
                        label="โทนผิว"
                        colors={SKIN_TONES}
                        value={char.skinTone}
                        onChange={(value) => updateCharacter(char.id, { skinTone: value })}
                      />
                      <ColorField
                        label="สีชุด"
                        colors={OUTFIT_COLORS}
                        value={char.outfitColor}
                        onChange={(value) => updateCharacter(char.id, { outfitColor: value })}
                      />
                      <ColorField
                        label="สีผม"
                        colors={HAIR_COLORS}
                        value={char.hairColor}
                        onChange={(value) => updateCharacter(char.id, { hairColor: value })}
                      />
                    </div>
                    <CharacterPreview character={char} />
                  </div>
                </div>
              ))}
              <button
                type="button"
                onClick={addCharacter}
                className="inline-flex items-center gap-2 rounded-full bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-800"
              >
                <Icon name="user" className="h-4 w-4" />
                เพิ่มตัวละคร
              </button>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-8">
              <SectionHead
                icon="book"
                title="Storyboard ให้เป็นภาษานักเรียนก่อน"
                subtitle="ในแต่ละหน้าให้เขียนแบบสั้นเข้าใจง่าย แล้วระบบจะนำไปเกลาเป็น Prompt มืออาชีพในขั้นถัดไป"
              />
              <div className="overflow-hidden rounded-3xl bg-white ring-1 ring-zinc-200">
                <div className="grid grid-cols-[90px_1fr_1fr] gap-0 border-b border-zinc-200 bg-zinc-50 px-4 py-3 text-xs font-semibold tracking-wide text-zinc-500">
                  <p>หน้า</p>
                  <p>เนื้อเรื่องแบบสั้น</p>
                  <p>ฉากและ Prompt ตั้งต้นของนักเรียน</p>
                </div>
                {state.storyboard.map((page, i) => (
                  <div key={page.page} className="grid grid-cols-[90px_1fr_1fr] gap-3 border-b border-zinc-100 px-4 py-4 last:border-b-0">
                    <div>
                      <p className="text-sm font-semibold text-zinc-800">{page.page}</p>
                      <p className="text-xs text-zinc-500">{page.label}</p>
                    </div>
                    <textarea
                      value={page.storyText}
                      onChange={(e) =>
                        setState((prev) => ({
                          ...prev,
                          storyboard: prev.storyboard.map((item, idx) =>
                            idx === i ? { ...item, storyText: e.target.value } : item,
                          ),
                        }))
                      }
                      className={`${textAreaClass} min-h-24`}
                      placeholder="เขียน 2-4 บรรทัด"
                    />
                    <div className="space-y-2">
                      <input
                        value={page.scene}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            storyboard: prev.storyboard.map((item, idx) =>
                              idx === i ? { ...item, scene: e.target.value } : item,
                            ),
                          }))
                        }
                        className={inputClass}
                        placeholder="ชื่อฉาก เช่น ลานแกะเทียนช่วงเย็น"
                      />
                      <textarea
                        value={page.studentPrompt}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            storyboard: prev.storyboard.map((item, idx) =>
                              idx === i ? { ...item, studentPrompt: e.target.value } : item,
                            ),
                          }))
                        }
                        className={`${textAreaClass} min-h-16`}
                        placeholder="Prompt ตั้งต้นของนักเรียน เช่น เด็กหญิงถือเทียน เดินในงานแห่เทียน"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-8">
              <SectionHead
                icon="wand"
                title="Prompt Studio: ตั้งต้นโดยนักเรียน แล้วระบบเกลาให้อัตโนมัติ"
                subtitle="ระบบจะผสมข้อมูลตัวละคร + สไตล์ + บริบทท้องถิ่น เพื่อให้ AI สร้างภาพตรงโจทย์มากขึ้น"
              />
              <div className="grid gap-4 rounded-3xl bg-white p-5 ring-1 ring-zinc-200 md:grid-cols-2">
                <Field label="น้ำเสียงบรรยาย">
                  <select
                    value={state.narrationTone}
                    onChange={(e) => setState((p) => ({ ...p, narrationTone: e.target.value as BuilderState["narrationTone"] }))}
                    className={inputClass}
                  >
                    <option value="classic">สละสลวยแบบวรรณศิลป์</option>
                    <option value="cinematic">เข้มข้นแบบภาพยนตร์</option>
                    <option value="gentle">อ่อนโยนแบบหนังสือเด็ก</option>
                  </select>
                </Field>
                <Field label="ระดับการเกลา Prompt">
                  <select
                    value={state.polishLevel}
                    onChange={(e) => setState((p) => ({ ...p, polishLevel: Number(e.target.value) as 1 | 2 | 3 }))}
                    className={inputClass}
                  >
                    <option value={1}>Level 1: เติมบริบทหลัก</option>
                    <option value={2}>Level 2: เพิ่มภาพจำและองค์ประกอบ</option>
                    <option value={3}>Level 3: คุณภาพระดับพรีเซนต์มืออาชีพ</option>
                  </select>
                </Field>
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={copyAllPrompts}
                  className="rounded-full bg-zinc-900 px-5 py-2 text-sm font-medium text-white transition hover:bg-zinc-800"
                >
                  คัดลอก Prompt ทั้งชุด
                </button>
                <button
                  type="button"
                  onClick={exportTxt}
                  className="rounded-full border border-zinc-300 bg-white px-5 py-2 text-sm font-medium text-zinc-700 transition hover:bg-zinc-100"
                >
                  ดาวน์โหลด .txt
                </button>
                <button
                  type="button"
                  onClick={exportJson}
                  className="rounded-full border border-zinc-300 bg-white px-5 py-2 text-sm font-medium text-zinc-700 transition hover:bg-zinc-100"
                >
                  ดาวน์โหลดโปรเจกต์ .json
                </button>
              </div>

              <div className="space-y-4">
                {prompts.map((item) => (
                  <div key={item.page} className="rounded-3xl bg-white p-5 ring-1 ring-zinc-200">
                    <div className="mb-3 flex items-center justify-between">
                      <p className="text-sm font-semibold text-zinc-800">
                        หน้า {item.page}: {item.label}
                      </p>
                      <button
                        type="button"
                        onClick={() => navigator.clipboard.writeText(item.polished)}
                        className="rounded-full border border-zinc-300 px-3 py-1 text-xs text-zinc-600 hover:bg-zinc-100"
                      >
                        คัดลอกหน้าเดียว
                      </button>
                    </div>
                    <PromptBlock title="Prompt ตั้งต้นจากนักเรียน" text={item.studentBase} tone="light" />
                    <PromptBlock title="Prompt เกลาแล้ว (พร้อมใช้กับ AI สร้างภาพ)" text={item.polished} tone="dark" />
                    <PromptBlock title="บทบรรยายสละสลวย" text={item.narration} tone="light" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>

        <div className="mt-10 flex items-center justify-between border-t border-zinc-200 pt-6">
          <button
            type="button"
            onClick={goPrev}
            disabled={step === 1}
            className="rounded-full border border-zinc-300 bg-white px-5 py-2 text-sm font-medium text-zinc-700 disabled:cursor-not-allowed disabled:opacity-40"
          >
            ย้อนกลับ
          </button>
          <button
            type="button"
            onClick={goNext}
            disabled={step === 5}
            className="rounded-full bg-zinc-900 px-5 py-2 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-40"
          >
            ถัดไป
          </button>
        </div>
      </main>

      {toast && <div className="toast-enter fixed bottom-6 right-6 rounded-2xl bg-zinc-900 px-4 py-2 text-sm text-white">{toast}</div>}

      <footer className="border-t border-zinc-200 bg-white/80 py-6 text-center text-xs text-zinc-500">
        โรงเรียนเสียมทองพิทยาคม | THIAN Model | Prompt-first workflow for student creators
      </footer>
    </div>
  );
}

function SectionHead({ icon, title, subtitle }: { icon: string; title: string; subtitle: string }) {
  return (
    <div className="space-y-3">
      <div className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs tracking-wide text-zinc-500 ring-1 ring-zinc-200">
        <Icon name={icon} className="h-4 w-4" />
        Prompt-first Storybook Builder
      </div>
      <h2 className="text-3xl font-semibold tracking-tight text-zinc-900 md:text-4xl">{title}</h2>
      <p className="max-w-3xl text-sm leading-relaxed text-zinc-600 md:text-base">{subtitle}</p>
    </div>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <label className="space-y-2">
      <p className="text-sm font-medium text-zinc-700">
        {label} {required && <span className="text-zinc-400">*</span>}
      </p>
      {children}
    </label>
  );
}

function ColorField({
  label,
  colors,
  value,
  onChange,
}: {
  label: string;
  colors: string[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-zinc-700">{label}</p>
      <div className="flex flex-wrap gap-2">
        {colors.map((color) => (
          <button
            key={color}
            type="button"
            onClick={() => onChange(color)}
            className={`h-7 w-7 rounded-full ring-2 transition ${value === color ? "ring-zinc-900" : "ring-transparent hover:ring-zinc-300"}`}
            style={{ backgroundColor: color }}
          />
        ))}
      </div>
    </div>
  );
}

function PromptBlock({ title, text, tone }: { title: string; text: string; tone: "light" | "dark" }) {
  return (
    <div className="mb-3 rounded-2xl border border-zinc-200">
      <p className="border-b border-zinc-200 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">{title}</p>
      <pre
        className={`overflow-x-auto whitespace-pre-wrap px-4 py-3 text-xs leading-relaxed ${tone === "dark" ? "bg-zinc-900 text-zinc-100" : "bg-zinc-50 text-zinc-700"}`}
      >
        {text}
      </pre>
    </div>
  );
}

function createStudentBasePrompt(page: StoryPage, state: BuilderState, style: (typeof STYLES)[number]) {
  const mainChar = state.characters[0];
  const charText = mainChar
    ? `${mainChar.name || "ตัวละครหลัก"}, ${mainChar.role}, outfit ${mainChar.outfitColor}, skin ${mainChar.skinTone}`
    : "main character";
  return [
    `scene: ${page.scene || "เทศกาลเทียนพรรษาในชุมชน"}`,
    `story context: ${page.storyText || "เล่าเหตุการณ์ตามหน้าเรื่อง"}`,
    `character: ${charText}`,
    `theme: ${state.theme || "การเรียนรู้คุณค่าของภูมิปัญญาท้องถิ่น"}`,
    `style baseline: ${style.name}`,
    page.studentPrompt ? `student direction: ${page.studentPrompt}` : "student direction: keep simple and clear",
  ].join(", ");
}

function createPolishedPrompt(page: StoryPage, state: BuilderState, style: (typeof STYLES)[number]) {
  const charSpec = state.characters
    .map(
      (char) =>
        `${char.name || "unnamed"} (${char.role}, ${char.bodyShape} body, skin ${char.skinTone}, hair ${char.hairColor}, outfit ${char.outfitColor}, personality ${char.personality || "balanced"})`,
    )
    .join("; ");

  const qualityLine =
    state.polishLevel === 1
      ? "clean composition, clear focal point"
      : state.polishLevel === 2
        ? "cinematic depth, layered foreground-middle-background, expressive lighting"
        : "premium editorial quality, highly detailed texture, museum-grade lighting, print-ready sharpness";

  return [
    `Professional illustrated book scene for page ${page.page} (${page.label})`,
    `Narrative brief: ${page.storyText || "follow storyboard intention with emotional clarity"}`,
    `Location and atmosphere: ${page.scene || "Ubon Ratchathani candle festival route at golden hour"}`,
    `Student creative direction: ${page.studentPrompt || "preserve student idea and make it visually coherent"}`,
    `Character consistency sheet: ${charSpec}`,
    `Style bible: ${style.visualKeywords}, palette ${style.palette}`,
    `Theme anchor: ${state.theme || "local wisdom, intergenerational learning"}`,
    `Composition: portrait 3:4, one dominant moment, no clutter, clear storytelling action`,
    `Rendering notes: ${qualityLine}`,
    `Negative prompts: distorted anatomy, floating objects, random text, watermark, extra fingers, low contrast, messy background`,
  ].join(". ");
}

function createPolishedNarration(text: string, tone: BuilderState["narrationTone"]) {
  if (!text.trim()) {
    return "เติมเนื้อหาใน Storyboard ก่อน แล้วระบบจะเกลาบทบรรยายให้อัตโนมัติ";
  }

  if (tone === "cinematic") {
    return `ท่ามกลางแสงที่เคลื่อนผ่านอย่างเชื่องช้า เหตุการณ์นี้ได้เปิดฉากช่วงสำคัญของเรื่อง: ${text.trim()} และพาตัวละครก้าวสู่จุดเปลี่ยนที่ไม่อาจหวนคืน`;
  }
  if (tone === "gentle") {
    return `เรื่องราวค่อยๆ คลี่ออกอย่างอบอุ่น: ${text.trim()} ทำให้ผู้อ่านมองเห็นความงดงามของผู้คนและประเพณีผ่านสายตาที่อ่อนโยน`;
  }
  return `ณ ช่วงเวลาที่ความทรงจำและความหมายมาบรรจบกัน ${text.trim()} จึงมิใช่เพียงเหตุการณ์หนึ่งหน้า หากคือถ้อยคำที่เชื่อมอดีต ปัจจุบัน และความหวังของชุมชน`;
}

function validateStep(step: StepId, state: BuilderState) {
  if (step === 1) {
    if (!state.fullName.trim()) return "กรุณากรอกชื่อ-นามสกุล";
    if (!state.nickname.trim()) return "กรุณากรอกชื่อเล่น";
    if (!state.grade.trim()) return "กรุณากรอกชั้นเรียน";
    if (!state.teamName.trim()) return "กรุณากรอกชื่อทีม";
  }
  if (step === 2) {
    if (!state.ebookTitle.trim()) return "กรุณาตั้งชื่อ E-Book";
    if (!state.theme.trim()) return "กรุณาระบุธีมหลัก";
  }
  if (step === 3) {
    if (!state.characters[0]?.name.trim()) return "กรุณาตั้งชื่อตัวละครหลัก";
  }
  if (step === 4) {
    const filled = state.storyboard.filter((item) => item.storyText.trim()).length;
    if (filled < 8) return `Storyboard ยังไม่พอ ต้องมีอย่างน้อย 8 หน้า (ตอนนี้ ${filled})`;
  }
  return "";
}

const inputClass =
  "w-full rounded-2xl border border-zinc-300 bg-white px-4 py-2.5 text-sm text-zinc-800 outline-none transition focus:border-zinc-500 focus:ring-2 focus:ring-zinc-200";
const textAreaClass = `${inputClass} min-h-20 resize-y`;
